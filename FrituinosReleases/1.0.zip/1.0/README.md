# Uso de Frituinos 1.0

## 1. Descomprime el .zip
En este vendrán binarios precompilados de todos los sistemas disponibles

## 2. Mueve la carpeta servers a home en las computadoras que trabajarán de servidores
Frituinos utiliza la ruta home/servers/ para encontrar los binarios remotamente desde la aplicación

### El sistema necesita el servidor Master y Autenticador para funcionar
Estos servidores son cruciales para el funcionamiento mínimo del sistema

Al iniciar una nueva instancia de Frituinos, el usuario default tendrá las siguientes credenciales

## Usuario: Admin
## Contraseña: passwordH0#
